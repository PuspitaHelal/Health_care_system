<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Medication;

class MedicationsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Static medication data
        $medications = [
            [
                'medication_id' => 1, // Replace with valid user IDs
                'name' => 'Paracetamol',
                'dosage' => '500mg',
                'frequency' => 'Twice a day',
                'time'=>'8:30:00',
                'start_date' => '2024-12-01',
                'end_date' => '2024-12-10',
            ],
            [
                'medication_id' => 2, // Replace with valid user IDs
                'name' => 'Ibuprofen',
                'dosage' => '200mg',
                'frequency' => 'Three times a day',
                'time'=>'14:30:00',
                'start_date' => '2024-12-05',
                'end_date' => '2024-12-15',
            ],
            [
                'medication_id' => 3, // Replace with valid user IDs
                'name' => 'Amoxicillin',
                'dosage' => '250mg',
                'frequency' => 'Twice a day',
                'time'=>'18:30:00',
                'start_date' => '2024-12-02',
                'end_date' => '2024-12-12',
            ],
        ];

        // Insert static data into the database
        foreach ($medications as $medication) {
            Medication::create($medication);
        }
    }
}

