<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\MedicationController;
use App\Http\Controllers\ReminderController;


use App\Http\Controllers\AdminController;

// Welcome route
Route::get('/', function () {
    return view('welcome');
});

// Dashboard route
Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

// Profile routes
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});



// Admin Dashboard Routes
Route::middleware('auth')->prefix('admin')->group(function () {
    Route::get('dashboard', [AdminController::class, 'dashboard'])->name('admin.dashboard');
    Route::get('users', [AdminController::class, 'userList'])->name('admin.users');
   
    Route::get('users/{user}', [AdminController::class, 'showUser'])->name('admin.user.show');
    
});





//Medication routes
Route::get('admin/medications', [MedicationController::class, 'index'])->name('admin.medications');
Route::get('admin/medications/create', [MedicationController::class, 'create'])->name('admin.medications.create');
Route::post('admin/medications/store', [MedicationController::class, 'store'])->name('admin.medications.store');


// Reminder routes
Route::get('admin/reminders', [ReminderController::class, 'index'])->name('admin.reminders');
Route::get('admin/reminders/create', [ReminderController::class, 'create'])->name('admin.reminders.create');
Route::post('admin/reminders', [ReminderController::class, 'store'])->name('admin.reminders.store');

require __DIR__.'/auth.php';