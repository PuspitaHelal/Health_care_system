<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Reminder extends Model
{
    // Use mass assignment for necessary fields
    protected $fillable = [
        'medication_id',   // Foreign key for the medication
        'reminder_time',   // The time the reminder should trigger
        'status',          // Status of the reminder (completed, missed)
    ];

    /**
     * Get the medication associated with the reminder.
     */
    public function medication()
    {
        return $this->belongsTo(Medication::class);
    }
    public function getRandomIconAttribute()
    {
        $icons = ['⏰', '🕒', '💊', '⌚'];
        return $icons[array_rand($icons)];
    }
    /**
     * The status of the reminder (completed or missed).
     */
    const STATUS_COMPLETED = 'completed';
    const STATUS_MISSED = 'missed';

    /**
     * Get the status of the reminder in a human-readable format.
     */
    public function getStatusLabelAttribute()
    {
        return ucfirst($this->status);  // Capitalize the first letter of the status
    }
}

