<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body class="bg-gray-900 text-white font-sans">

    <!-- Full-screen Container -->
    <div class="flex items-center justify-center min-h-screen">

        <!-- Card Container -->
        <div class="text-center px-6 md:px-12 py-8 md:py-16 bg-gray-800 bg-opacity-80 rounded-lg shadow-xl">
            
            <!-- Title Centered in the middle -->
            <h1 class="text-4xl font-semibold text-white mb-6">Welcome to Smart Healthcare</h1>

            <!-- Login Button Centered below title -->
            <a href="<?php echo e(route('login')); ?>" class="bg-blue-600 text-white px-6 py-3 rounded-full text-lg font-semibold shadow-lg hover:shadow-xl transition duration-200">Login</a>
        </div>
    </div>

</body>
</html>
<?php /**PATH C:\Users\intel\Herd\Health_care_system\resources\views/welcome.blade.php ENDPATH**/ ?>