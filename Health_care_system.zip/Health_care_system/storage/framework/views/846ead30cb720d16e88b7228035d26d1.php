<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body class="bg-gray-800 text-white">
    <div class="container mx-auto py-8">
        <h1 class="text-4xl">Welcome to Smart Healthcare</h1>
        <a href="<?php echo e(route('login')); ?>" class="text-blue-400">Login</a>
    </div>
</body>
</html>
<?php /**PATH C:\Users\cse\Herd\Health_care_system\resources\views/welcome.blade.php ENDPATH**/ ?>