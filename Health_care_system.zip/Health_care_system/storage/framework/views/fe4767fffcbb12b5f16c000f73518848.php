

<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-dark text-blue-200">
    <div class="container mx-auto py-8">
        <h1 class="text-2xl font-bold mb-4">User List</h1>
        <table class="table-auto w-full bg-darkCard">
            <thead>
                <tr class="text-left">
                    <th class="px-4 py-2">Name</th>
                    <th class="px-4 py-2">Email</th>
                    <th class="px-4 py-2">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="border px-4 py-2"><?php echo e($user->name); ?></td>
                    <td class="border px-4 py-2"><?php echo e($user->email); ?></td>
                    <td class="border px-4 py-2">
                        <a href="<?php echo e(route('admin.user.show', $user->id)); ?>" class="text-blue-400">View</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\intel\Herd\Health_care_system\resources\views/admin/users/index.blade.php ENDPATH**/ ?>