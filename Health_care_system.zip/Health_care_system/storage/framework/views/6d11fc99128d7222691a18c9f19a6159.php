<h1>Add Reminder</h1>

<form action="<?php echo e(route('admin.reminders.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="medication_id">Medication</label>
        <select name="medication_id" id="medication_id" class="form-control" required>
            <?php $__currentLoopData = $medications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($medication->id); ?>"><?php echo e($medication->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-group">
        <label for="time">Time</label>
        <input type="time" name="time" id="time" class="form-control" required>
    </div>

    <div class="form-group">
        <label for="status">Status</label>
        <select name="status" id="status" class="form-control" required>
            <option value="completed">Completed</option>
            <option value="missed">Missed</option>
        </select>
    </div>

    <button type="submit" class="btn btn-success mt-3">Save Reminder</button>
</form>
<?php /**PATH C:\Users\intel\Herd\Health_care_system\resources\views/admin/reminders/create.blade.php ENDPATH**/ ?>