<h1>Add Medication</h1>

<form action="/medications" method="POST">
    <?php echo csrf_field(); ?>
    <input type="text" name="name" placeholder="Medication Name">
    <input type="text" name="dosage" placeholder="Dosage">
    <input type="text" name="frequency" placeholder="Frequency">
    <input type="date" name="start_date">
    <input type="date" name="end_date">
    <button type="submit">Add Medication</button>
</form>

    

   
<?php /**PATH C:\Users\cse\Herd\Health_care_system\resources\views/admin/medications/create.blade.php ENDPATH**/ ?>