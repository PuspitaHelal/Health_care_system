<h1>Reminders</h1>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<a href="<?php echo e(route('admin.reminders.create')); ?>" class="btn btn-primary">Add Reminder</a>

<table class="table table-bordered mt-3">
    <thead>
        <tr>
            <th>Medication</th>
            <th>Time</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $reminders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reminder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($reminder->medication->name); ?></td>
                <td><?php echo e($reminder->time); ?></td>
                <td><?php echo e($reminder->status); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\Users\intel\Herd\Health_care_system\resources\views/admin/reminders/index.blade.php ENDPATH**/ ?>