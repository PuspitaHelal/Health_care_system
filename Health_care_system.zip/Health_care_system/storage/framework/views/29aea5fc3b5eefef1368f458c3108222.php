<h1>Medications</h1>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<a href="<?php echo e(route('admin.medications.create')); ?>" class="btn btn-primary">Add Medication</a>

<table class="table table-bordered mt-3">
    <thead>
        <tr>
            <th>Name</th>
            <th>Dosage</th>
            <th>Frequency</th>
            <th>Start Date</th>
            <th>End Date</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $medications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($medication->name); ?></td>
                <td><?php echo e($medication->dosage); ?></td>
                <td><?php echo e($medication->frequency); ?></td>
                <td><?php echo e($medication->start_date); ?></td>
                <td><?php echo e($medication->end_date); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\Users\cse\Herd\Health_care_system\resources\views/admin/medications/index.blade.php ENDPATH**/ ?>