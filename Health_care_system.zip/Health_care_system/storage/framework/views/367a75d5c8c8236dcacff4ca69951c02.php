

<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-dark text-blue-200">
    <div class="container mx-auto py-8">
        <h1 class="text-2xl font-bold mb-4">Admin Dashboard</h1>
        <a href="<?php echo e(route('admin.users')); ?>" class="text-blue-400">View Users</a> |
        <a href="<?php echo e(route('admin.medications')); ?>" class="text-blue-400">View Medications</a> |
        <a href="<?php echo e(route('admin.reminders')); ?>" class="text-blue-400">View Reminders</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\intel\Herd\Health_care_system\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>