<?php
function foo()
{
    echo "Example function.\n";
    // return $retval;
}
?>

<h1>Add Medication</h1>
{{-- form action=add to database --}}

<form method="POST" action="store">
    @csrf
    <input type="text" name="name" placeholder="Medication Name">
    <input type="text" name="dosage" placeholder="Dosage">
    <input type="text" name="frequency" placeholder="Frequency">
    <input type="date" name="start_date">
    <input type="date" name="end_date">
    <button type="submit">Add Medication</button>
</form>

    

   
