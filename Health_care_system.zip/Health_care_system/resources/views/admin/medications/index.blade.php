<h1>Medications</h1>

@if (session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
@endif

<a href="{{ route('admin.medications.create') }}" class="btn btn-primary">Add Medication</a>

<table class="table table-bordered mt-3">
    <thead>
        <tr>
            <th>Name</th>
            <th>Dosage</th>
            <th>Frequency</th>
            <th>Start Date</th>
            <th>End Date</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($medications as $medication)
            <tr>
                <td>{{ $medication->name }}</td>
                <td>{{ $medication->dosage }}</td>
                <td>{{ $medication->frequency }}</td>
                <td>{{ $medication->start_date }}</td>
                <td>{{ $medication->end_date }}</td>
            </tr>
        @endforeach
    </tbody>
</table>
