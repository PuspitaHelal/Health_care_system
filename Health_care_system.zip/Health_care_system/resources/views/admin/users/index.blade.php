@extends('layouts.app')

@section('content')
<div class="min-h-screen bg-dark text-blue-200">
    <div class="container mx-auto py-8">
        <h1 class="text-2xl font-bold mb-4">User List</h1>
        <table class="table-auto w-full bg-darkCard">
            <thead>
                <tr class="text-left">
                    <th class="px-4 py-2">Name</th>
                    <th class="px-4 py-2">Email</th>
                    <th class="px-4 py-2">Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($users as $user)
                <tr>
                    <td class="border px-4 py-2">{{ $user->name }}</td>
                    <td class="border px-4 py-2">{{ $user->email }}</td>
                    <td class="border px-4 py-2">
                        <a href="{{ route('admin.user.show', $user->id) }}" class="text-blue-400">View</a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection
