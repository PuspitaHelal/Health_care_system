<h1>User Details</h1>
<p>Name: {{ $user->name }}</p>
<p>Email: {{ $user->email }}</p>
<p>Role: {{ $user->role }}</p>
<!-- Add other user details as necessary -->
