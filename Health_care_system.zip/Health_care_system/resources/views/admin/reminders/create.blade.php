<h1>Add Reminder</h1>

<form action="{{ route('admin.reminders.store') }}" method="POST">
    @csrf
    <div class="form-group">
        <label for="medication_id">Medication</label>
        <select name="medication_id" id="medication_id" class="form-control" required>
            @foreach ($medications as $medication)
                <option value="{{ $medication->id }}">{{ $medication->name }}</option>
            @endforeach
        </select>
    </div>

    <div class="form-group">
        <label for="time">Time</label>
        <input type="time" name="time" id="time" class="form-control" required>
    </div>

    <div class="form-group">
        <label for="status">Status</label>
        <select name="status" id="status" class="form-control" required>
            <option value="completed">Completed</option>
            <option value="missed">Missed</option>
        </select>
    </div>

    <button type="submit" class="btn btn-success mt-3">Save Reminder</button>
</form>
