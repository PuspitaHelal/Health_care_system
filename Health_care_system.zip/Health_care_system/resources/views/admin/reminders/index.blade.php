<h1>Reminders</h1>

@if (session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
@endif

<a href="{{ route('admin.reminders.create') }}" class="btn btn-primary">Add Reminder</a>

<table class="table table-bordered mt-3">
    <thead>
        <tr>
            <th>Medication</th>
            <th>Time</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($reminders as $reminder)
            <tr>
                <td>{{ $reminder->medication->name }}</td>
                <td>{{ $reminder->time }}</td>
                <td>{{ $reminder->status }}</td>
            </tr>
        @endforeach
    </tbody>
</table>
