<div class="min-h-screen bg-darkBg text-gray-200">
    <div class="container mx-auto py-8">
        <h1 class="text-2xl font-bold mb-4">{{ $user->name }}'s Profile</h1>
        <h2 class="text-xl font-semibold mb-2">Medications</h2>
        <ul class="mb-4">
            @foreach ($medications as $medication)
            <li class="bg-darkCard p-4 rounded mb-2">
                <strong>{{ $medication->name }}</strong> - {{ $medication->dosage }}
            </li>
            @endforeach
        </ul>
        <h2 class="text-xl font-semibold mb-2">Reminders</h2>
        <ul>
            @foreach ($reminders as $reminder)
            <li class="bg-darkCard p-4 rounded mb-2 flex items-center">
                <span class="text-2xl mr-4">{{ $reminder->random_icon }}</span>
                <div>
                    Reminder at: {{ $reminder->time }} <br>
                    Status: {{ ucfirst($reminder->status) }}
                </div>
            </li>
            @endforeach
        </ul>
    </div>
</div>
