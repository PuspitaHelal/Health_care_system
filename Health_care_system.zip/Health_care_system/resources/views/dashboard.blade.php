{{-- @extends('layouts.app') --}}

@section('content')
<div class="min-h-screen bg-dark text-blue-200">
    <div class="container mx-auto py-8">
        <h1 class="text-2xl font-bold mb-4">Admin Dashboard</h1>
        <a href="{{ route('admin.users') }}" class="text-blue-400">View Users</a> |
        <a href="{{ route('admin.medications') }}" class="text-blue-400">View Medications</a> |
        <a href="{{ route('admin.reminders') }}" class="text-blue-400">View Reminders</a>
    </div>
</div>



{{-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
</head>
<body class="bg-gray-900 text-white font-sans">

    <div class="flex items-center justify-center min-h-screen">

       

@section('content')
<div class="min-h-screen bg-dark text-blue-200">
    <div class="container mx-auto py-8">
        <h1 class="text-2xl font-bold mb-4">Admin Dashboard</h1>
        <a href="{{ route('admin.users') }}" class="text-blue-400">View Users</a> |
        <a href="{{ route('admin.medications') }}" class="text-blue-400">View Medications</a> |
        <a href="{{ route('admin.reminders') }}" class="text-blue-400">View Reminders</a>
    </div>
</div>

    </div>

</body>
</html> --}}
