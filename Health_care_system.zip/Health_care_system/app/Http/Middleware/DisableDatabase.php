<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\DB;

class DisableDatabase
{
    public function handle($request, Closure $next)
    {
        DB::disconnect(); // Disconnect the database
        return $next($request);
    }
}
