<?php

namespace App\Http\Controllers;

use App\Models\Reminder;
use App\Models\Medication;
use Illuminate\Http\Request;

class ReminderController extends Controller
{
    // Display the list of reminders
    public function index()
    {
        // Fetch all reminders from the database
        $reminders = Reminder::all(); 

        // Return the view and pass the reminders data
        return view('admin.reminders.index', compact('reminders'));
    }

    // Create a new reminder
    public function create()
    {
        // Fetch all medications to create the reminder
        $medications = Medication::all();

        return view('admin.reminders.create', compact('medications'));
    }

    // Store the new reminder
    public function store(Request $request)
    {
        // Validate the incoming request data
        $request->validate([
            'medication_id' => 'required|exists:medications,id',
            'frequency' => 'required|date_format:H:i',
            'status' => 'required|string',
        ]);

        // Create a new reminder record
        Reminder::create([
            'medication_id' => $request->medication_id,
            'time' => $request->time,
            'status' => $request->status,
        ]);

        // Redirect back with a success message
        return redirect()->route('admin.reminders')->with('success', 'Reminder added successfully');
    }
}

