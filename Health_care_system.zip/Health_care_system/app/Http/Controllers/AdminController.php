<?php 
namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Medication;
use App\Models\Reminder;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function dashboard()
    {
        return view('admin.dashboard');
    }

    public function userList()
    {
        $users = User::all();
        return view('admin.users.index', compact('users'));
    }

    public function showUser(User $user)
    {
        $medications = $user->medications; // Assuming relationship exists
        $reminders = $user->reminders;     // Assuming relationship exists
        return view('admin.users.show', compact('user', 'medications', 'reminders'));
    }

    public function medicationList()
    {
        $medications = Medication::all();
        return view('admin.medications.index', compact('medications'));
    }

    public function reminderList()
    {
        $reminders = Reminder::all();
        return view('admin.reminders.index', compact('reminders'));
    }
}
