<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    /**
     * Display the specified user.
     *
     * @param  int  $id
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        // Find the user by ID
        $user = User::findOrFail($id);

        // Return a view with the user data
        return view('admin.users.show', compact('user'));
    }
}
