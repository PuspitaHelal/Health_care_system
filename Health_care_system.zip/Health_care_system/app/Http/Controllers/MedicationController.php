<?php

namespace App\Http\Controllers;

use App\Models\Medication;
use Illuminate\Http\Request;

class MedicationController extends Controller
{
    // Display the list of medications
    public function index()
    {
        // Fetch all medications from the database
        $medications = Medication::all(); 

        // Return the view and pass the medications data
        return view('admin.medications.index', compact('medications'));
    }

    // Create a new medication
    public function create()
    {
        return view('admin.medications.create');
    }

    public function store(Request $request)
{
    $request->validate([
        'user_id' => 'required|exists:users,id',
        'name' => 'required|string|max:255',
        'dosage' => 'required|string',
        'frequency' => 'required|string',
        'start_date' => 'required|date',
        'end_date' => 'required|date',
    ]);

    //store the request data to database: TODO
   
    
    $user = Medication::create([
        'name' => $request->name,
        'dosage' => $request->dosage,
        'frequency' => $request->frequency,
        'start_date' => $request->start_date,
        'end_date' => $request->end_date,
    ]);
    // 'medication_id' => 1, // Replace with valid user IDs
    //             'name' => 'Paracetamol',
    //             'dosage' => '500mg',
    //             'frequency' => 'Twice a day',
    //             'time'=>'8:30:00',
    //             'start_date' => '2024-12-01',
    //             'end_date' => '2024-12-10',
    // ([
    //     'user_id' => $request->user_id, // Use the provided user_id
    //     'name' => $request->name,
    //     'dosage' => $request->dosage,
    //     'frequency' => $request->frequency,
    //     'start_date' => $request->start_date,
    //     'end_date' => $request->end_date,
    // ]);

    return redirect()->route('admin.medications')->with('success', 'Medication added successfully');
}
}