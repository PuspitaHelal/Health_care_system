<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Medication extends Model
{
    // Use mass assignment to allow certain attributes to be set
    protected $fillable = [
        'medication_id',  // Assuming you have a 'user_id' foreign key
        'name',     // Medication name (e.g., "Paracetamol")
        'dosage',   // Dosage (e.g., "1 tablet")
        'frequency', // Frequency of taking the medication (e.g., "Once a day")
      
        'start_date', // Start date of medication
        'end_date',   // End date of medication
    ];

    /**
     * Get the user associated with the medication.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the reminders for the medication.
     */
    public function reminders()
    {
        return $this->hasMany(Reminder::class);
    }
}
